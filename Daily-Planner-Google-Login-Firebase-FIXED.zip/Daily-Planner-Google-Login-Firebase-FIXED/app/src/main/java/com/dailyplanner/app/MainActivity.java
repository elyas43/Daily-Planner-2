package com.dailyplanner.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.annotation.NonNull;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialException;

import com.google.android.libraries.identity.googleid.GetGoogleIdOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;

import org.json.JSONObject;

import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private WebView webView;
    private FirebaseAuth auth;
    private CredentialManager credentialManager;
    private final Executor executor = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        auth = FirebaseAuth.getInstance();
        credentialManager = CredentialManager.create(this);

        webView = new WebView(this);
        setContentView(webView);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);

        webView.addJavascriptInterface(new AuthBridge(), "AndroidAuth");

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(
                    WebView view,
                    WebResourceRequest request) {
                return super.shouldInterceptRequest(view, request);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                syncAuthState();
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    private void syncAuthState() {
        if (webView == null) return;
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) {
            webView.evaluateJavascript("window.setNativeAuth(false,'','');", null);
        } else {
            webView.evaluateJavascript(
                    "window.setNativeAuth(true," +
                            JSONObject.quote(user.getDisplayName() == null ? "" : user.getDisplayName()) + "," +
                            JSONObject.quote(user.getEmail() == null ? "" : user.getEmail()) +
                            ");",
                    null);
        }
    }

    private void startCredentialRequest() {
        int webClientIdRes = getResources().getIdentifier(
                "default_web_client_id",
                "string",
                getPackageName()
        );

        if (webClientIdRes == 0) {
            showError("Web Client ID گوگل در Firebase تنظیم نشده است. در Firebase Authentication > Sign-in method > Google تنظیمات Google را کامل کن و google-services.json جدید را دوباره دانلود کن.");
            return;
        }

        String webClientId = getString(webClientIdRes).trim();

        if (webClientId.isEmpty()) {
            showError("Web Client ID گوگل خالی است. google-services.json جدید را از Firebase دانلود کن.");
            return;
        }

        GetGoogleIdOption googleIdOption = new GetGoogleIdOption.Builder()
                .setFilterByAuthorizedAccounts(false)
                .setServerClientId(webClientId)
                .build();

        GetCredentialRequest request = new GetCredentialRequest.Builder()
                .addCredentialOption(googleIdOption)
                .build();

        credentialManager.getCredentialAsync(
                this,
                request,
                new CancellationSignal(),
                executor,
                new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                    @Override
                    public void onResult(GetCredentialResponse result) {
                        handleCredential(result.getCredential());
                    }

                    @Override
                    public void onError(@NonNull GetCredentialException e) {
                        showError("ورود با Google انجام نشد: " + e.getMessage());
                    }
                }
        );
    }

    private void handleCredential(Credential credential) {
        if (credential instanceof CustomCredential
                && GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(credential.getType())) {
            GoogleIdTokenCredential googleCredential =
                    GoogleIdTokenCredential.createFrom(((CustomCredential) credential).getData());
            firebaseAuthWithGoogle(googleCredential.getIdToken());
        } else {
            showError("نوع حساب Google پشتیبانی نشد.");
        }
    }

    private void firebaseAuthWithGoogle(String idToken) {
        AuthCredential credential = GoogleAuthProvider.getCredential(idToken, null);
        auth.signInWithCredential(credential)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        syncAuthState();
                    } else {
                        String msg = task.getException() == null
                                ? "ورود ناموفق بود."
                                : task.getException().getMessage();
                        showError("Firebase Login: " + msg);
                    }
                });
    }

    private void signOut() {
        auth.signOut();
        credentialManager.clearCredentialStateAsync(
                new androidx.credentials.ClearCredentialStateRequest(),
                new CancellationSignal(),
                executor,
                new CredentialManagerCallback<Void, androidx.credentials.exceptions.ClearCredentialException>() {
                    @Override
                    public void onResult(Void result) {
                        syncAuthState();
                    }

                    @Override
                    public void onError(@NonNull androidx.credentials.exceptions.ClearCredentialException e) {
                        syncAuthState();
                    }
                }
        );
    }

    private void showError(String message) {
        runOnUiThread(() -> {
            if (webView != null) {
                webView.evaluateJavascript(
                        "window.setNativeAuthError(" + JSONObject.quote(message) + ");",
                        null);
            }
        });
    }

    public class AuthBridge {
        @JavascriptInterface
        public void signInWithGoogle() {
            runOnUiThread(() -> startCredentialRequest());
        }

        @JavascriptInterface
        public void signOut() {
            runOnUiThread(() -> MainActivity.this.signOut());
        }
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }
}
